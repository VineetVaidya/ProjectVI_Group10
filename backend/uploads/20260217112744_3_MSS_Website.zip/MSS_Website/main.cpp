/*
Author:   Dr. (James) Elliott Coleshill
Date:     April 2023
Purpose:  This web server software has been designed and devleoped to support a performance assignement
			in CSCN73060 - Project IV.
*/
#define PORT_NUMBER 23500

#include "crow_all.h"
#include <iostream>
#include <deque>
using namespace std;
using namespace crow;

//This function streams static file contents into the RESTFul response object for
//transmission back to the client
void sendFile(response& res, string filename, string type)
{
	ifstream in("../public/" + filename, ifstream::in);
	if (in){
		ostringstream contents;
		contents << in.rdbuf();
		in.close();
		res.set_header("Content-Type", type);
		res.write(contents.str());
	}
	else{
		res.code = 404;
		res.write("Not Found");
	}

	res.end();
}

//This function adds an event to the end of the events log
bool addEvent(string MSS_Component, string EventDetails, int EventID)
{
	ofstream* ofs = nullptr;

	if(EventID == 0)
		ofs = new ofstream("../public/bin/" + MSS_Component + ".txt", ofstream::out);
	else
		ofs = new ofstream("../public/bin/" + MSS_Component + ".txt", ofstream::app);

	if (ofs)
	{
		*ofs << EventID << "," << EventDetails << endl;
		ofs->close();
		return true;
	}
	
	return false;
}

//Reads and writes the selected events file into the response object
void displayEvent(response& res, string MSS_Component)
{
	ifstream in("../public/bin/" + MSS_Component + ".txt", ifstream::in);
	if (in)
	{
		ostringstream contents;
		contents << in.rdbuf();
		in.close();
		contents << "<div><a href=\"http://localhost:23500\"> RETURN HOME </a><div>";
		res.set_header("Content-Type", "text/html");
		res.write(contents.str());
		res.code = 200;
	}
	else
	{
		res.code = 404;
		res.write("Not Found");
	}
	res.end();
}

//Update or deletes the provided EventID from the components file
//NOTE:  NewDetails is optional param used for Updates only
bool updateEvent(string MSS_Component, string EventID, string Method, string NewDetails = "")
{
	deque<string> Contents;			//The contents of the file less the requested ID
	bool bFound = false;			//Flag to determine if the EventID was found or not
	string ReadLine = "";

	ifstream in("../public/bin/" + MSS_Component + ".txt", ifstream::in);
	if (in)
	{
		while (!in.eof())
		{
			getline(in, ReadLine);
			int loc = ReadLine.find(',');
			string ID = ReadLine.substr(0, loc);

			if (ID != EventID)
				Contents.push_back(ReadLine);		//Store
			else
			{
				if(Method == "DELETE")
					bFound = true;						//Skip and flag found
				else if (Method == "PATCH")
				{
					bFound = true;
					string newEntry = EventID + "," + NewDetails;
					Contents.push_back(newEntry);
					bFound = true;
				}
			}
		}
		in.close();

		ofstream ofs("../public/bin/" + MSS_Component + ".txt", ofstream::out);		//Clean file here
		for (auto x = Contents.begin(); x != Contents.end(); x++)
			ofs << *x << endl;

		ofs.close();
	}

	if (bFound)
		return true;
	else
		return false;
}

//The following helper functions manage the different types of static files available on the website.
void sendHTML(response& res, string filename) { sendFile(res, filename + ".html", "text/html"); }
void sendImage(response& res, string filename) { sendFile(res, "images/" + filename, "image/jpeg"); }
void sendScript(response& res, string filename) { sendFile(res, "scripts/" + filename, "text/javascript"); }
void sendStyle(response& res, string filename) { sendFile(res, "styles/" + filename, "text/css"); }


int main()
{	
	crow::SimpleApp app;

	//ROOT ROUTE - Default index.html page
	CROW_ROUTE(app, "/")
		([](const request& req, response& res) { sendHTML(res, "index"); });

	// defines a generic route for an HTML pages
	CROW_ROUTE(app, "/<string>")
		([](const request& req, response& res, string filename)
			{
				sendHTML(res, filename);
			});

	/**** The following routes support the event logging capabilities for the web server***/
	CROW_ROUTE(app, "/Event/<string>").methods(HTTPMethod::POST)
		([](const request& req, response& res, string MSS_Component) 
			{
				string EventDetails = req.url_params.get("details");
				
				//Event ID Counters
				static unsigned int SSRMS_Event_Count = 0;
				static unsigned int MBS_Event_Count = 0;
				static unsigned int SPDM_Event_Count = 0;
				string msg = "";		//Generic response message to be generated based on request
				bool result = false;	//Result of writing event to the log file

				if (MSS_Component == "SSRMS")
					result = addEvent(MSS_Component, EventDetails, SSRMS_Event_Count++);
				else if (MSS_Component == "MBS")
					result = addEvent(MSS_Component, EventDetails, MBS_Event_Count++);
				else if (MSS_Component == "SPDM")
					result = addEvent(MSS_Component, EventDetails, SPDM_Event_Count++);
				else
				{
					res.code = 400;
					msg = "Bad Request.  No MSS Component " + MSS_Component;
					res.write(msg.c_str());
				}

				if (result)
				{
					res.code = 202;
					msg = "<div>Event Added Successfully <a href=\"http://localhost:23500\"> RETURN HOME </a></div>";
					res.write(msg.c_str());
				}
				else
				{
					res.code = 500;
					msg = "INTERNAL SERVER ERROR";
					res.write(msg.c_str());
				}

				res.end();
			});

	CROW_ROUTE(app, "/Event/<string>").methods(HTTPMethod::DELETE, HTTPMethod::PATCH)
		([](const request& req, response& res, string MSS_Component)
			{
				string EventID = "";
				string NewDetails = "";

				string Method = method_name(req.method);
				if (Method == "DELETE")
				{
					EventID = req.url_params.get("EventID");
				}
				else
				{
					EventID = req.url_params.get("EventID");
					NewDetails = req.url_params.get("details");

				}

				string msg = "";		//Generic response message to be generated based on request
				bool result = false;	//Result of writing event to the log file

				if (MSS_Component == "SSRMS")
					result = updateEvent(MSS_Component, EventID, Method, NewDetails);
				else if (MSS_Component == "MBS")
					result = updateEvent(MSS_Component, EventID, Method, NewDetails);
				else if (MSS_Component == "SPDM")
					result = updateEvent(MSS_Component, EventID, Method, NewDetails);
				else
				{
					res.code = 400;
					msg = "Bad Request.  No MSS Component " + MSS_Component;
					res.write(msg.c_str());
				}

				if (result)
				{
					res.code = 202;
					msg = "<div>Event Successfully Updated <a href=\"http://localhost:23500\"> RETURN HOME </a></div>";
					res.write(msg.c_str());
				}
				else
				{
					res.code = 500;
					msg = "INTERNAL SERVER ERROR";
					res.write(msg.c_str());
				}

				res.end();
			});

	CROW_ROUTE(app, "/Event/<string>").methods(HTTPMethod::GET)
		([](const request& req, response& res, string MSS_Component)
			{
				displayEvent(res, MSS_Component);
			});

    /********* Standard routes to support styles and images *********/
	CROW_ROUTE(app, "/styles/<string>")([](const request& req, response& res, string filename) { sendStyle(res, filename); });
	CROW_ROUTE(app, "/images/<string>")([](const request& req, response& res, string filename) { sendImage(res, filename); });

	app.port(PORT_NUMBER).multithreaded().run();

	return 1;
}